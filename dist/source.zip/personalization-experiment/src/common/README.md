Files needed by [this](https://github.com/djfm/ytdpnl-server) project and [that](https://github.com/djfm/ytdpnl-extension) project.
I hate git submodules.
