export type ParticipantChannelSource = {
	pos: number;
	channelId: string;
};

export default ParticipantChannelSource;
