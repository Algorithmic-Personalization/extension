export default {
	'production-server-url': 'https://ytdpnl.fmdj.fr',
	'development-server-url': 'https://messanges.fmdj.fr',
};
