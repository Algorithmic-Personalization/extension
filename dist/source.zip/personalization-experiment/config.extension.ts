export default {
	'production-server-url': 'https://personalization-server.csail.mit.edu/',
	'development-server-url': 'https://personalization-server.csail.mit.edu/',
};
